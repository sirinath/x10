
## Planned Features

Below is the randomly ordered list of planned features.

-   Ready-to-go Hazelcast Cache Server Image for Amazon EC2

-   Symmetric Encryption for Java Client

-   Distributed `java.util.concurrent.DelayQueue` implementation.

-   Distributed Tree implementation.

-   Distributed Tuple implementation.

-   Built-in file based storage.


